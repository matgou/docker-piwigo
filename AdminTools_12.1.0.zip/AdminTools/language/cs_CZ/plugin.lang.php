<?php

$lang['Combine JS&CSS'] = 'Kombinace JS&amp;CSS';
$lang['Debug languages'] = 'Debug překladů';
$lang['Debug template'] = 'Debug šablony vzhledu';
$lang['Viewing as <b>%s</b>.'] = 'Zobrazení jako <b>%s</b>.';
$lang['Properties page'] = 'Stránka vlastností';
$lang['Quick edit'] = 'Rychlá editace';
$lang['Revert'] = 'Nazpět';
$lang['Save'] = 'Uložit';
$lang['Saved'] = 'Uloženo';
$lang['Save visit in history'] = 'Ukládat návštevy do historie';
$lang['Show SQL queries'] = 'Zobrazit SQL queries';
$lang['View as'] = 'Zobrazit jako';

$lang['Closed icon position'] = 'Poloha ikony pro zavření';
$lang['Give access to quick edit to photo owners even if they are not admin'] = 'Udělit přístup do rychlé editace vlastníkům fotek i když nejsou admin';
$lang['Open toolbar by default'] = 'Výchozí otevření panelu nástrojů';
$lang['left'] = 'levý';
$lang['right'] = 'pravý';