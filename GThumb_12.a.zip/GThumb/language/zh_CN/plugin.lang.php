<?php

$lang['Thumbnails max height'] = '缩略图最大高度';
$lang['Margin between thumbnails'] = '缩略图间距';
$lang['Double the size of the first thumbnail'] = '第一张缩略图为两倍大小';
$lang['Cache the big thumbnails (recommended)'] = '缓存大缩略图(推荐)';
$lang['Scale thumbnails'] = '缩放缩略图方式';
$lang['Cache Informations'] = '缓存信息';
$lang['Purge thumbnails cache'] = '清空缩略图缓存';
$lang['%d file'] = '%d 个文件';
$lang['%d files'] = '%d 个文件';
$lang['Cache have been generated'] = '缓存生成完毕';
$lang['Pre-cache thumbnails'] = '预缓存缩略图';
$lang['Delete images in GThumb+ cache.'] = '删除GThumb+缓存中的图片.';
$lang['Finds images that have not been cached and creates the cached version.'] = '找寻未缓存的图片并创建缓存版本.';

$lang['Show thumbnails caption'] = '显示缩略图标题';
$lang['Show rating score in caption'] = '在标题中显示评分';