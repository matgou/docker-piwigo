<?php

$lang['Combine JS&CSS'] = 'Combine JS&amp;CSS';
$lang['Debug languages'] = 'Debug languages';
$lang['Debug template'] = 'Debug template';
$lang['Viewing as <b>%s</b>.'] = 'Viewing as <b>%s</b>.';
$lang['Properties page'] = 'Properties page';
$lang['Quick edit'] = 'Quick edit';
$lang['Revert'] = 'Revert';
$lang['Save'] = 'Save';
$lang['Saved'] = 'Saved';
$lang['Save visit in history'] = 'Save visit in history';
$lang['Show SQL queries'] = 'Show SQL queries';
$lang['View as'] = 'View as';
$lang['Closed icon position'] = 'Closed icon position';
$lang['Give access to quick edit to photo owners even if they are not admin'] = 'Give access to quick edit to photo owners even if they are not admin';
$lang['Open toolbar by default'] = 'Open toolbar by default';
$lang['left'] = 'left';
$lang['right'] = 'right';

?>