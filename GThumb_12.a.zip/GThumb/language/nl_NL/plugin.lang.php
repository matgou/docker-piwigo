<?php

$lang['Thumbnails max height'] = 'Maximale hoogte van de thumbnails';
$lang['Margin between thumbnails'] = 'Marge tussen de thumbnails';
$lang['Double the size of the first thumbnail'] = 'Verdubbel de grootte van de eerste thumbnail';
$lang['Cache the big thumbnails (recommended)'] = 'Neem de grote thumbnails op in de cache (aanbevolen)';
$lang['Scale thumbnails'] = 'Schaal thumbnails';
$lang['Cache Informations'] = 'Cache informatie';
$lang['Purge thumbnails cache'] = 'Verwijder de thumbnails cache';
$lang['%d file'] = '%d bestand';
$lang['%d files'] = '%d bestanden';
$lang['Cache have been generated'] = 'Cache is aangemaakt';
$lang['Pre-cache thumbnails'] = 'Pre-cache de thumbnails';
$lang['Delete images in GThumb+ cache.'] = 'Verwijder de afbeeldingen in de GThumb+ cache.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Zoekt de afbeeldingen die nog niet in de cache zijn opgenomen en creëert versies voor de cache.';

$lang['Show thumbnails caption'] = 'Toon thumbnails onderschrift';
$lang['Show rating score in caption'] = 'Toon waardering-score in bijschrift';