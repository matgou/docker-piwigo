<?php
$lang['See the remaining %d photos']='Bekijk de overige %d foto�s';
?>