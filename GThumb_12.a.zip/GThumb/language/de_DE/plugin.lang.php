<?php



$lang['%d file'] = '%d Datei';
$lang['%d files'] = '%d Dateien';
$lang['Cache have been generated'] = 'Zwischenspeicher wurde generiert';
$lang['Cache Informations'] = 'Informationen zum Zwischenspeicher';
$lang['Cache the big thumbnails (recommended)'] = 'Große Vorschaubilder zwischenspeichern (empfohlen)';
$lang['Delete images in GThumb+ cache.'] = 'Bilder aus dem GThumb+ Zwischenspeicher löschen';
$lang['Double the size of the first thumbnail'] = 'Doppelt so groß wie das erste Vorschaubild';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Bilder finden, die nicht zwischengespeichert wurden und Zwischenspeicher-Version erstellen';
$lang['Margin between thumbnails'] = 'Abstand zwischen den Vorschaubildern';
$lang['Pre-cache thumbnails'] = 'Vorschaubilder zwischenspeichern';
$lang['Purge thumbnails cache'] = 'Vorschaubilder-Zwischenspeicher leeren';
$lang['Scale thumbnails'] = 'Vorschaubilder skalieren';
$lang['Thumbnails max height'] = 'Maximal Höhe der Vorschaubilder';
$lang['Show thumbnails caption'] = 'Bildunterschriften der Vorschaubilder anzeigen';
$lang['Show rating score in caption'] = 'Bewertung in Bildunterschrift anzeigen';