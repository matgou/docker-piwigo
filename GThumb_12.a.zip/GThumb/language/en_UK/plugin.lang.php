<?php

$lang['Thumbnails max height'] = 'Thumbnails max height';
$lang['Margin between thumbnails'] = 'Margin between thumbnails';
$lang['Double the size of the first thumbnail'] = 'Double the size of the first thumbnail';
$lang['Cache the big thumbnails (recommended)'] = 'Cache the big thumbnails (recommended)';
$lang['Scale thumbnails'] = 'Scale thumbnails';
$lang['Cache Informations'] = 'Cache Informations';
$lang['Purge thumbnails cache'] = 'Purge thumbnails cache';
$lang['%d file'] = '%d file';
$lang['%d files'] = '%d files';
$lang['Cache have been generated'] = 'Cache have been generated';
$lang['Pre-cache thumbnails'] = 'Pre-cache thumbnails';
$lang['Delete images in GThumb+ cache.'] = 'Delete images in GThumb+ cache.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Finds images that have not been cached and creates the cached version.';
$lang['Show thumbnails caption'] = 'Show thumbnails caption';
$lang['Show rating score in caption'] = 'Show rating score in caption';
?>