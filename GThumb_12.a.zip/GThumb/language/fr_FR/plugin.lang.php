<?php

$lang['Thumbnails max height'] = 'Hauteur maximum des miniatures';
$lang['Margin between thumbnails'] = 'Marge entre les miniatures';
$lang['Double the size of the first thumbnail'] = 'Doubler la taille de la première miniature';
$lang['Cache the big thumbnails (recommended)'] = 'Mettre en cache les grosse miniatures (recommandé)';
$lang['Scale thumbnails'] = 'Redimensionner les miniatures';
$lang['Cache Informations'] = 'Informations du cache';
$lang['Purge thumbnails cache'] = 'Vider le cache';
$lang['%d file'] = '%d fichier';
$lang['%d files'] = '%d fichiers';
$lang['Cache have been generated'] = 'Le cache a été généré';
$lang['Pre-cache thumbnails'] = 'Mettre en cache les miniatures';
$lang['Delete images in GThumb+ cache.'] = 'Efface les images du cache de GThumb+.';
$lang['Finds images that have not been cached and creates the cached version.'] = "Met en cache les images qui n'ont pas encore été crées.";
$lang['Show thumbnails caption'] = 'Afficher les légendes des miniatures';
$lang['Show rating score in caption'] = 'Montrer le score dans la légende';
?>