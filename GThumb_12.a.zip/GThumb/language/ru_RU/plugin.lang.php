<?php

$lang['Thumbnails max height'] = 'Максимальная высота миниатюры';
$lang['Margin between thumbnails'] = 'Интервал между миниатюрами';
$lang['Double the size of the first thumbnail'] = 'Двойной размер первой миниатюры';
$lang['Cache the big thumbnails (recommended)'] = 'Кэшировать большие миниатюры (рекомендуется)';
$lang['Scale thumbnails'] = 'Масштабировать миниатюры';
$lang['Cache Informations'] = 'Кэшировать данные';
$lang['Purge thumbnails cache'] = 'Очистить кэш миниатюр';
$lang['%d file'] = '%d файл';
$lang['%d files'] = '%d файлов';
$lang['Cache have been generated'] = 'Кэш записан';
$lang['Pre-cache thumbnails'] = 'Предварительное кэширование миниатюр';
$lang['Delete images in GThumb+ cache.'] = 'Удалить фотографии из кэша GThumb+.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Найти фотографии, которые не были кэшированы и провести кэширование для них.';

$lang['Show thumbnails caption'] = 'Показать легенду';
$lang['Show rating score in caption'] = 'Показ оценочных баллов в заголовке';