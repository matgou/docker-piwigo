<?php
$lang['See the remaining %d photos']='Siehe die noch folgenden %d Fotos';
?>