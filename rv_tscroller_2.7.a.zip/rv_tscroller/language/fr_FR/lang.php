<?php
$lang['See the remaining %d photos']='Voir les %d photos restantes';
?>