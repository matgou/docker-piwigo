<?php
$lang['See the remaining %d photos']='Skatīt atlikušās %d fotogrāfijas';
?>