<?php

$lang['Thumbnails max height'] = 'Maksymalna wysokość miniatur';
$lang['Margin between thumbnails'] = 'Margines między miniaturami';
$lang['Double the size of the first thumbnail'] = 'Podwój rozmiar pierwszej miniatury';
$lang['Cache the big thumbnails (recommended)'] = 'Umieść w pamięci podręcznej duże miniatury (rekomendowane)';
$lang['Scale thumbnails'] = 'Skaluj miniatury';
$lang['Cache Informations'] = 'Umieść w pamięci podręcznej informacje';
$lang['Purge thumbnails cache'] = 'Wyczyść pamięć podręczną miniatur';
$lang['%d file'] = '%d plik';
$lang['%d files'] = '%d pliki';
$lang['Cache have been generated'] = 'Pamięć podręczna została utworzona';
$lang['Pre-cache thumbnails'] = 'Wywołuj miniatury z pamięci podręcznej';
$lang['Delete images in GThumb+ cache.'] = 'Usuń zdjęcia z pamięci podręcznej GThumb+ .';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Znajduje zdjęcia, które nie zostały umieszczone w pamięci podręcznej i tworzy tam ich kopie.';

$lang['Show thumbnails caption'] = 'Pokaż etykiety miniaturek';
$lang['Show rating score in caption'] = 'Pokaż wynik oceny w podpisie';