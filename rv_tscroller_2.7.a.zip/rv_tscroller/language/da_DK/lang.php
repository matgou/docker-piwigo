<?php
$lang['See the remaining %d photos'] = 'Se de resterende %d fotoer';
?>