<?php
// +-----------------------------------------------------------------------+
// | Piwigo - a PHP based photo gallery                                    |
// +-----------------------------------------------------------------------+
// | Copyright(C) 2008-2013 Piwigo Team                  http://piwigo.org |
// | Copyright(C) 2003-2008 PhpWebGallery Team    http://phpwebgallery.net |
// | Copyright(C) 2002-2003 Pierrick LE GALL   http://le-gall.net/pierrick |
// +-----------------------------------------------------------------------+
// | This program is free software; you can redistribute it and/or modify  |
// | it under the terms of the GNU General Public License as published by  |
// | the Free Software Foundation                                          |
// |                                                                       |
// | This program is distributed in the hope that it will be useful, but   |
// | WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      |
// | General Public License for more details.                              |
// |                                                                       |
// | You should have received a copy of the GNU General Public License     |
// | along with this program; if not, write to the Free Software           |
// | Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, |
// | USA.                                                                  |
// +-----------------------------------------------------------------------+
$lang['Revert'] = 'Буцаах';
$lang['Combine JS&CSS'] = 'JS ба CSS-г нэгтгэх';
$lang['Quick edit'] = 'Засах';
$lang['View as'] = 'Харах';
$lang['Save'] = 'Хадгалах';
$lang['Saved'] = 'Амжилттай хадгаллаа';
$lang['left'] = 'зүүн';
$lang['right'] = 'баруун';
$lang['Closed icon position'] = 'Хаагдсан дүрслэлийн байршил';
$lang['Show SQL queries'] = 'SQL query хүсэлтийг харуулах';
$lang['Save visit in history'] = 'Хандалтыг бүртгэж хадгалах';
$lang['Open toolbar by default'] = 'Засварлах багажыг нээлттэй байлгах ';
$lang['Viewing as <b>%s</b>.'] = '<b>%s</b> маягаар харах';
$lang['Give access to quick edit to photo owners even if they are not admin'] = 'Зургийн эзэд админ эрхгүй байсан ч засвар хийх боломжтой';
$lang['Properties page'] = 'Дэлгэрэнгүй үзүүлэлт';
$lang['Debug languages'] = 'Хэлийг засах';
$lang['Debug template'] = 'Загварыг засах';