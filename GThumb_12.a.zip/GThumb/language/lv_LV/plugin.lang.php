<?php

$lang['Thumbnails max height'] = 'Sīkbilžu maksimālais augstums';
$lang['Margin between thumbnails'] = 'Atstarpe starp sīkbildēm';
$lang['Double the size of the first thumbnail'] = 'Dubultot pirmās sīkbildes izmēru';
$lang['Cache the big thumbnails (recommended)'] = 'Izmantot Cache atmiņu (kešot) lielajām sīkbildēm (ieteicams)';
$lang['Scale thumbnails'] = 'Mērogot sīkbildes';
$lang['Cache Informations'] = 'Izmantot Cache Informācijai';
$lang['Purge thumbnails cache'] = 'Iztīrīt sīkbilžu cache atmiņu';
$lang['%d file'] = '%d fails';
$lang['%d files'] = '%d faili';
$lang['Cache have been generated'] = 'Cache atmiņa izveidota';
$lang['Pre-cache thumbnails'] = 'Kešot sīkbildes';
$lang['Delete images in GThumb+ cache.'] = 'Dzēst attēlus iekš GThumb+ cache.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Atrod attēlos, kas vēl nav kešoti un izveido kešotu versiju.';

$lang['Show thumbnails caption'] = 'Parādīt satverto sīkbildi';
$lang['Show rating score in caption'] = 'rātīt novērtējumu tvērienā';