<?php

$lang['Thumbnails max height'] = 'Maximálna výška náhľadov';
$lang['Margin between thumbnails'] = 'Odstup medzi náhľadmi';
$lang['Double the size of the first thumbnail'] = 'Dvojitá veľkosť prvého náhľadu';
$lang['Cache the big thumbnails (recommended)'] = 'Vyrovnávacia pamäť veľých náhľadov (odporúčané)';
$lang['Scale thumbnails'] = 'Škála náhľadov';
$lang['Cache Informations'] = 'Informácie o vyrovnávacej pamäti';
$lang['Purge thumbnails cache'] = 'Vyčistenie vyrovnávacej pamäti náhľadov';
$lang['%d file'] = '%d súbor';
$lang['%d files'] = '%d súborov';
$lang['Cache have been generated'] = 'Vytváranie vyrovnávacej pamäti';
$lang['Pre-cache thumbnails'] = 'Predvytvorenie vyrovnávacej pamäti náhľadov';
$lang['Delete images in GThumb+ cache.'] = 'Vymazanie fotiek v GThumb+ vyrovnávacej pamäti.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Vyhľadanie fotiek, ktoré nie sú vo vyrovnávacej pamäti a vytvorenie ich verzie.';

$lang['Show thumbnails caption'] = 'Zobraziť názov náhľadov';
$lang['Show rating score in caption'] = 'Ukázať hodnotiace skóre v titulku';