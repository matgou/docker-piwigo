<?php

$lang['Thumbnails max height'] = 'Mέγιστο ύψος μικρογραφιών';
$lang['Margin between thumbnails'] = 'Απόσταση μεταξύ των μικρογραφιώνs';
$lang['Double the size of the first thumbnail'] = 'Διπλό μέγεθος της πρώτης μικρογραφίας';
$lang['Cache the big thumbnails (recommended)'] = 'Cache στις μεγάλες μικρογραφίες (προτείνεται)';
$lang['Scale thumbnails'] = 'Κλίμακα μικρογραφιών';
$lang['Cache Informations'] = 'Πληροφορίες Cache';
$lang['Purge thumbnails cache'] = 'Εκκαθάριση cache μικρογραφιών';
$lang['%d file'] = '%d αρχείο';
$lang['%d files'] = '%d αρχεία';
$lang['Cache have been generated'] = 'H Cache έχει δημιουργηθεί';
$lang['Pre-cache thumbnails'] = 'Pre-cache μικρογραφίες';
$lang['Delete images in GThumb+ cache.'] = 'Διαγραφή εικόνων στο GThumb+ cache.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Εύρεση εικόνων που δεν έχουν γίνει cach και δημιουργία έκσοδης cache'; 

$lang['Show thumbnails caption'] = 'Εμφάνιση λεζάντας μικρογραφιών ';
$lang['Show rating score in caption'] = 'Εμφάνιση βαθμολογίας αξιολόγησης στη λεζάντα';