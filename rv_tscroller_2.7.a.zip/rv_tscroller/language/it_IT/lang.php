<?php
$lang['See the remaining %d photos'] = 'Vedere le %d foto rimanenti';
?>