<?php
$lang['See the remaining %d photos'] = 'A többi %d kép megjelenítése';
?>