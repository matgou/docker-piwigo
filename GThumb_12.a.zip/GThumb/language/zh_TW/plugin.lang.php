<?php

$lang['Thumbnails max height'] = '縮圖最大高度'; 
$lang['Margin between thumbnails'] = '縮圖之間的邊界'; 
$lang['Double the size of the first thumbnail'] = '把第一個縮圖放大一倍'; 
$lang['Cache the big thumbnails (recommended)'] = '高速緩存大縮圖（建議使用)'; 
$lang['Scale thumbnails'] = '放大縮小縮圖'; 
$lang['Cache Informations'] = '緩存訊息'; 
$lang['Purge thumbnails cache'] = '清除縮圖緩存'; 
$lang['%d file'] = '%d 檔案'; 
$lang['%d files'] = '%d 檔案'; 
$lang['Cache have been generated'] = '緩存已經建立'; 
$lang['Pre-cache thumbnails'] = '預先緩存縮圖'; 
$lang['Delete images in GThumb+ cache.'] = '刪除在gthumb+緩存的圖像'; 
$lang['Finds images that have not been cached and creates the cached version.'] = '尋找沒有被緩存的圖像，並創建緩存的版本'; 
$lang['Show thumbnails caption'] = '顯示縮圖標題'; 

?>