<?php
$lang['See the remaining %d photos']='See the remaining %d photos';
?>