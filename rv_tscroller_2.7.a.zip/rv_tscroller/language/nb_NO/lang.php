<?php
$lang['See the remaining %d photos']='Se gjenv�rende %d bilder';
?>