<?php

$config_default = array(
  'height'          => 200,
  'margin'          => 10,
  'nb_image_page'   => 80,
  'big_thumb'       => true,
  'cache_big_thumb' => true,
  'method'          => 'crop',
  'show_thumbnail_caption' => true,
  'show_score_in_caption' => false,
);

?>