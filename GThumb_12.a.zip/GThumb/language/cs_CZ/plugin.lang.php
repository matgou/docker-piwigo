<?php

$lang['Thumbnails max height'] = 'Max výška náhledu';
$lang['Margin between thumbnails'] = 'Margin mezi náhledy';
$lang['Double the size of the first thumbnail'] = 'Zdvojit velikost prvního náhledu';
$lang['Cache the big thumbnails (recommended)'] = 'Cachovat velké náhledy (doporučeno)';
$lang['Scale thumbnails'] = 'Rozměr náhledů';
$lang['Cache Informations'] = 'Cachovat Informace';
$lang['Purge thumbnails cache'] = 'Vyčistit cache náhledů';
$lang['%d file'] = '%d soubor';
$lang['%d files'] = '%d souborů';
$lang['Cache have been generated'] = 'Cache byla vygenerována';
$lang['Pre-cache thumbnails'] = 'Před-cache náhledů';
$lang['Delete images in GThumb+ cache.'] = 'Odstranit obrázky v GThumb a cache.';
$lang['Finds images that have not been cached and creates the cached version.'] = 'Najít obrázky, které nebyly dosud uloženy v cache a vytvořit jejich cache verzi.';

$lang['Show thumbnails caption'] = 'Zobrazit titulek náhledů';
?>